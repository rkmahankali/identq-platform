
(function(){
  const root=document.documentElement;
  try{const t=localStorage.getItem("identq-theme");if(t)root.setAttribute("data-theme",t)}catch(e){}
  const tb=document.getElementById("themeBtn");
  if(tb)tb.addEventListener("click",()=>{
    const dark=root.getAttribute("data-theme")==="dark"||(!root.getAttribute("data-theme")&&matchMedia("(prefers-color-scheme: dark)").matches);
    const next=dark?"light":"dark";root.setAttribute("data-theme",next);
    try{localStorage.setItem("identq-theme",next)}catch(e){}
    location.reload();
  });
  const toc=document.getElementById("toc"),mb=document.getElementById("menuBtn");
  if(mb&&toc){mb.addEventListener("click",()=>{const o=toc.classList.toggle("open");mb.setAttribute("aria-expanded",o)});
    toc.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{toc.classList.remove("open");mb.setAttribute("aria-expanded","false")}));}
  const links=[...document.querySelectorAll(".toc ul.sub a")];
  if(links.length){const io=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){links.forEach(l=>l.classList.toggle("active",l.getAttribute("href").endsWith("#"+e.target.id)))}})},{rootMargin:"-30% 0px -60% 0px"});
    document.querySelectorAll("section.blk").forEach(s=>io.observe(s));}
  const h=document.getElementById("heat");
  if(h){let x="";for(let i=0;i<144;i++){const r=(i*37)%100;const c=r<3?"b":r<10?"w":"";x+=`<span class="${c}" title="Practice ${i+1}"></span>`}h.innerHTML=x}
  const q=document.getElementById("q"),box=document.getElementById("sres");let idx=null;
  function esc(t){return t.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
  async function load(){if(idx)return idx;const r=await fetch("search.json");idx=await r.json();return idx}
  if(q){q.addEventListener("input",async()=>{const v=q.value.trim().toLowerCase();if(v.length<2){box.style.display="none";return}
    const data=await load();const words=v.split(/\s+/);
    const hits=data.map(d=>{const hay=(d.t+" "+d.x).toLowerCase();let sc=0;for(const w of words){if(!hay.includes(w))return null;sc+=(d.t.toLowerCase().includes(w)?5:1)}return [sc,d]}).filter(Boolean).sort((a,b)=>b[0]-a[0]).slice(0,14);
    box.innerHTML=hits.length?hits.map(([s,d])=>`<a href="${d.u}"><b>${esc(d.p)}</b>${esc(d.t)}</a>`).join(""):"<a>No results</a>";box.style.display="block"});
    document.addEventListener("click",e=>{if(!e.target.closest(".searchbox"))box.style.display="none"});}
})();
