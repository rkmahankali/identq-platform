
(function(){
  function show(id){document.querySelectorAll('.pvpanel').forEach(p=>p.hidden=p.id!==id);document.querySelectorAll('.pvtab').forEach(b=>{const on=b.dataset.p===id;b.classList.toggle('on',on);b.setAttribute('aria-selected',on)})}
  document.querySelectorAll('.pvtab').forEach(b=>b.addEventListener('click',()=>show(b.dataset.p)));
  function fromHash(){const h=location.hash.slice(1);if(!h)return;const el=document.getElementById(h);if(!el)return;const p=el.closest('.pvpanel');if(p){show(p.id);setTimeout(()=>el.scrollIntoView({block:'center'}),50);el.classList.add('flash');setTimeout(()=>el.classList.remove('flash'),2000)}}
  window.addEventListener('hashchange',fromHash);fromHash();window.addEventListener('load',()=>{setTimeout(fromHash,400);setTimeout(fromHash,1500)});
  const lb=document.getElementById('lb');
  if(lb){document.querySelectorAll('a.zoom').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();lb.querySelector('img').src=a.getAttribute('href');lb.querySelector('p').textContent=a.dataset.cap;lb.hidden=false}));
    lb.addEventListener('click',e=>{if(e.target===lb||e.target.classList.contains('lbx'))lb.hidden=true});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')lb.hidden=true});}
})();
