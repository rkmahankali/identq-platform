/* iDentQ blueprint access gate: decrypts pages in the browser for signed-in users. */
(async function () {
  var NAME = 'identq-k';
  var page = document.documentElement.getAttribute('data-page') || 'index.html';
  function b64d(s) { return Uint8Array.from(atob(s), function (c) { return c.charCodeAt(0); }); }
  function stored() { try { return sessionStorage.getItem(NAME) || localStorage.getItem(NAME); } catch (e) { return null; } }
  function forget() { try { sessionStorage.removeItem(NAME); localStorage.removeItem(NAME); } catch (e) {} }
  function toLogin() { location.replace('login.html?next=' + encodeURIComponent(page + location.hash)); }
  var raw = stored();
  if (!raw) { toLogin(); return; }
  var key;
  try { key = await crypto.subtle.importKey('raw', b64d(raw), 'AES-GCM', false, ['decrypt']); } catch (e) { forget(); toLogin(); return; }
  async function dec(buf) { var u = new Uint8Array(buf); return crypto.subtle.decrypt({ name: 'AES-GCM', iv: u.slice(0, 12) }, key, u.slice(12)); }
  var plainFetch = window.fetch.bind(window);
  async function getEnc(path) { var r = await plainFetch(path, { cache: 'no-store' }); if (!r.ok) throw new Error('missing ' + path); return dec(await r.arrayBuffer()); }
  var html;
  try { html = new TextDecoder().decode(await getEnc('data/' + page + '.enc')); } catch (e) { forget(); toLogin(); return; }
  window.fetch = function (u, o) {
    if (typeof u === 'string' && /^search\.json/.test(u)) {
      return getEnc('data/search.json.enc').then(function (b) { return new Response(b, { headers: { 'content-type': 'application/json' } }); });
    }
    return plainFetch(u, o);
  };
  var hash = location.hash;
  document.open(); document.write(html); document.close();
  async function images() {
    var cache = {};
    async function url(src) {
      if (!cache[src]) cache[src] = getEnc('data/' + src + '.enc').then(function (b) { return URL.createObjectURL(new Blob([b], { type: 'image/jpeg' })); });
      return cache[src];
    }
    var imgs = document.querySelectorAll('img[src^="screens/"]');
    for (var i = 0; i < imgs.length; i++) { imgs[i].src = await url(imgs[i].getAttribute('src')); }
    var links = document.querySelectorAll('a[href^="screens/"]');
    for (var j = 0; j < links.length; j++) { links[j].setAttribute('href', await url(links[j].getAttribute('href'))); }
  }
  function signOut() {
    var b = document.createElement('button');
    b.type = 'button'; b.textContent = 'Sign out';
    b.style.cssText = 'position:fixed;top:12px;right:14px;z-index:60;font:13px Arial,sans-serif;padding:7px 12px;border-radius:8px;border:1px solid #D8D2E2;background:#fff;color:#4F378B;cursor:pointer';
    b.addEventListener('click', function () { forget(); location.href = 'login.html'; });
    document.body.appendChild(b);
  }
  function ready(fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }
  ready(function () {
    signOut();
    images();
    if (hash) setTimeout(function () { var el = document.getElementById(hash.slice(1)); if (el && !el.closest('.pvpanel')) el.scrollIntoView(); }, 400);
  });
})();
